# hyprpolkitagent
A simple polkit authentication agent for Hyprland, written in QT/QML.

![](./assets/screenshot.png)

## Usage

See [the hyprland wiki](https://wiki.hyprland.org/Hypr-Ecosystem/hyprpolkitagent/)